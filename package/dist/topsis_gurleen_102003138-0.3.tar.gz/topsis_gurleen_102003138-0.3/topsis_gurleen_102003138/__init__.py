from topsis_102003138 import *
if __name__=="__main__":
    main()